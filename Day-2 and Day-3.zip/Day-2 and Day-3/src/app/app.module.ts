import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GenderPipe } from './gender.pipe';
import { HttpclientdemoComponent } from './httpclientdemo/httpclientdemo.component';
import {HttpclientexampleComponent} from './httpclientexample/httpclientexample.component';
import { EmployeeCountComponent } from './employee-count/employee-count.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
import { TemplateFormsComponent } from './template-forms/template-forms.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
@NgModule({
  declarations: [
    AppComponent,
    GenderPipe,
    HttpclientdemoComponent,HttpclientexampleComponent, EmployeeCountComponent, PagenotfoundComponent, HomeComponent, TemplateFormsComponent, ReactiveFormsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [],
  bootstrap: [HomeComponent]
})
export class AppModule { }
