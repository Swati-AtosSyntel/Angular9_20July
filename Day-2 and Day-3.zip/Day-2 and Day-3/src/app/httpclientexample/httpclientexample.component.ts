import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Repository } from './Repository';
@Component({
  selector: 'app-httpclientexample',
  templateUrl: './httpclientexample.component.html',
  styleUrls: ['./httpclientexample.component.css']
})
export class HttpclientexampleComponent implements OnInit {

baseUrl="https://api.github.com/";
userName:string="Swati";
repos:Repository[];

  constructor(public http:HttpClient) { }

  ngOnInit(): void {
    this.getRepositories();
  }
  getRepositories(){
    return this.http.get<Repository[]>(
      this.baseUrl+'users/'+this.userName+'/repos'
    ).subscribe((response)=>{
    console.log("response received");
    console.log(response);
    this.repos=response;
    },
    (error)=>{console.log("Request failed")},
    ()=>{console.log("Request completed")}
    )

  }

}
