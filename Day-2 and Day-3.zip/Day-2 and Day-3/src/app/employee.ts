export interface IEmployee{
    id:number;
    name:string;
    salary:number;
    city:string;
    age:number;
    gender:string;
    dob:Date;
    pan:string;
    mobile:string;
}