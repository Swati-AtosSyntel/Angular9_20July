import { Component, Input, OnInit } from '@angular/core';
import { Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-employee-count',
  templateUrl: './employee-count.component.html',
  styleUrls: ['./employee-count.component.css']
})
export class EmployeeCountComponent implements OnInit {

  @Input()
  All:number;
  @Input()
  Male:number;
  @Input()
  Female:number;

  selectedRadioButtonValue:string='All';
  constructor() { }
@Output()
countRadioButtonSelectionChanged:EventEmitter<string>=new EventEmitter<string>();

  ngOnInit(): void {
  }
onRadioButtonSelectionChange(){
  this.countRadioButtonSelectionChanged.emit(this.selectedRadioButtonValue);
  console.log(this.selectedRadioButtonValue);
}
}
