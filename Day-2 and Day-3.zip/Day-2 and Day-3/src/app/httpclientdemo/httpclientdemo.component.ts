import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Repos } from './Repos';
@Component({
  selector: 'app-httpclientdemo',
  templateUrl: './httpclientdemo.component.html',
  styleUrls: ['./httpclientdemo.component.css']
})
export class HttpclientdemoComponent implements OnInit {

  constructor(private http:HttpClient) { }
  baseUrl:string="https://api.github.com/";
  userName="SPA2021";

repositories:Repos[];

  ngOnInit(): void {
    this.getRepositories();
  }
  getRepositories(){
    return this.http.get<Repos[]>(
    this.baseUrl+'users/'+this.userName+'/repos'
    ).subscribe(
      (response)=>{
      console.log('response received');
      console.log(response);
      this.repositories=response;
      },
      (error)=>{
        console.error("Request failed");
      },
      ()=>
      {
        console.log("Request completed");
      }
    )

  }

}
